import React, { Component } from "react";
 
class Tests extends Component {
  render() {
    return (
      <div>
          <h2>Running tests</h2>
          <p>a1</p>
          <p>a2</p>
          <p>a3</p>
          <p>a4</p>
          <h2>Tests in queue</h2>
          <p>b1</p>
          <p>b2</p>
          <p>b3</p>
          <p>b4</p>
      </div>
    );
  }
}
 
export default Tests;
