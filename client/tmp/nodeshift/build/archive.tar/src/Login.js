import React, { Component } from "react";
import LoginPage from "./LoginPage";

class Login extends Component {
    render() {
        return(
            <div>asdasdsa</div>
        )
    }
}

export default Login;