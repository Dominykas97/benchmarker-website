#/bin/sh 
npx nodeshift --deploy.port=3000 --expose 
