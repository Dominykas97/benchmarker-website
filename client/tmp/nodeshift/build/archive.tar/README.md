**To deploy on Openshift, run locally:**
```
npx nodeshift --expose
```

**To sync local files with Openshift:**
```
./syncWithOpenshift.sh
```
