#/bin/sh 
npx nodeshift --deploy.port=5000 --expose
